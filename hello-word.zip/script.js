alert("olá mundo!")

const nomeUsuaria = prompt("digite aqui seu nome")

alert("Bem vinda ao meu primeiro site, " + nomeUsuaria)